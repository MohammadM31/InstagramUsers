import express from 'express';import helmet from 'helmet';import cors from 'cors';import rateLimit from 'express-rate-limit';
import {auth} from './auth.js';import {api} from './routes.js';import {startWorker} from './worker.js';
const app=express();app.set('trust proxy',1);app.use(helmet(),cors({origin:process.env.CORS_ORIGIN?.split(',')||true}),express.json({limit:'1mb'}));
app.use(rateLimit({windowMs:6e4,limit:120}));
app.get('/health',(_,r)=>r.json({ok:true}));
app.use('/api/auth',auth);app.use('/api',api);
app.use((e,_q,res,_n)=>{console.error(e);res.status(e.status||500).json({error:e.message})});
const port=process.env.PORT||3000;app.listen(port,()=>console.log('API on :'+port));
if(process.env.INLINE_WORKER==='1')startWorker();
