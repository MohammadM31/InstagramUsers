import {Worker} from 'bullmq';import {redis,cached} from './cache.js';import {q} from './db.js';
const DISCLAIMER='Public data only. User confirmed ToS at signup; scrape logged for audit.';
async function fetchProfile(handle){
 const {IG_ACCESS_TOKEN:t,IG_USER_ID:id}=process.env;
 if(t&&id){ // Preferred: official Business Discovery API (public business/creator accounts)
  const f=`business_discovery.username(${handle}){followers_count,media.limit(25){like_count,comments_count,media_type,timestamp,caption}}`;
  const r=await(await fetch(`https://graph.facebook.com/v21.0/${id}?fields=${encodeURIComponent(f)}&access_token=${t}`)).json();
  const b=r.business_discovery;if(!b)throw new Error(r.error?.message||'Business Discovery failed');
  return{source:'business_discovery',followers:b.followers_count,posts:(b.media?.data||[]).map(m=>({type:m.media_type,at:m.timestamp,likes:m.like_count,comments:m.comments_count,caption:m.caption||''}))};}
 // DEMO MODE: synthetic data. INTEGRATION POINT: add proxy-rotated scraper here if you accept the ToS risk.
 const T=['REEL','CAROUSEL_ALBUM','IMAGE'];
 return{source:'demo',followers:5000+Math.floor(Math.random()*30000),posts:Array.from({length:12},(_,i)=>({type:T[i%3],at:new Date(Date.now()-i*864e5*2).toISOString(),likes:Math.floor(Math.random()*3000),comments:Math.floor(Math.random()*120),caption:'Demo post '+i}))};}
export async function processScrape({userId,competitorId,handle}){
 const d=await cached(`scrape:${handle}`,3600,()=>fetchProfile(handle)); // Redis TTL 1h
 await q('INSERT INTO scrape_audit(user_id,handle,source,disclaimer) VALUES($1,$2,$3,$4)',[userId,handle,d.source,DISCLAIMER]);
 await q('UPDATE competitors SET followers=$1,last_scraped=now() WHERE id=$2',[d.followers,competitorId]);
 await q('DELETE FROM competitor_posts WHERE competitor_id=$1',[competitorId]);
 for(const p of d.posts)await q(`INSERT INTO competitor_posts(competitor_id,type,posted_at,likes,comments,caption,expires_at) VALUES($1,$2,$3,$4,$5,$6,now()+interval '30 days')`,[competitorId,p.type,p.at,p.likes,p.comments,p.caption]);
 return d.source;}
export function startWorker(){
 const w=new Worker('scrape',j=>processScrape(j.data),{connection:redis,concurrency:2,limiter:{max:200,duration:3600000}}); // 200 calls/hr
 w.on('failed',(j,e)=>console.error('scrape failed',j?.data?.handle,e.message));
 setInterval(()=>q('DELETE FROM competitor_posts WHERE expires_at<now()').catch(()=>{}),36e5); // 30-day retention
 return w;}
if(process.argv[1].endsWith('worker.js'))startWorker();
